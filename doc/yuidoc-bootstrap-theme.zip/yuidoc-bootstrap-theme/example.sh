
yuidoc -t ./ -H ./helpers/helpers.js ./example/


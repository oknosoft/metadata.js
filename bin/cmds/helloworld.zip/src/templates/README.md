## Шаблоны
- [cursors](cursors) - файлы указателей мыши
- [imgs](imgs) - исходники графических файлов, объединяемые в css base64
- [printing_plates](printing_plates) - шаблоны печатных форм
- [xml](xml_plates) - шаблоны элементов интерфейса
- [html](html_plates) - шаблоны html


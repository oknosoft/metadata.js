/**
 * Created 13.08.2015<br />
 * &copy; http://www.oknosoft.ru 2014-2015
 * @author	Evgeniy Malyarov
 *
 * @module  options
 */

jasmine.DEFAULT_TIMEOUT_INTERVAL = 10000;